package UOSense.UOSense_Backend.common.converter;

import UOSense.UOSense_Backend.common.enumClass.SubDescription;

public class SubDescriptionConverter extends EnumBaseConverter<SubDescription> {
    public SubDescriptionConverter() {
        super(SubDescription.class) ;
    }
}
