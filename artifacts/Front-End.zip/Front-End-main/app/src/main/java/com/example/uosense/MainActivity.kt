version https://git-lfs.github.com/spec/v1
oid sha256:253e06970baaa713b8638a2e2ef74336823c16079dfeffd7d2ee71b522d26ce3
size 38441
