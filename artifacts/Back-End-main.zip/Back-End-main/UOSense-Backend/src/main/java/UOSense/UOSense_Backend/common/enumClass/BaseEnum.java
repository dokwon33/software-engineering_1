package UOSense.UOSense_Backend.common.enumClass;

public interface BaseEnum {
    String getValue();
}
